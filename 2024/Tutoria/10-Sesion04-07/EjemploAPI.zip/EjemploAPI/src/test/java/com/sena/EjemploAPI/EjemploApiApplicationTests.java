package com.sena.EjemploAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
